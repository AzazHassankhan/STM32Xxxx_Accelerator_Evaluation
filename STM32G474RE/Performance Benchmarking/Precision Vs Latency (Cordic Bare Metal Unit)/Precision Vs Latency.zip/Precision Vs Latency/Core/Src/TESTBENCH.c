/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#include "stm32g4xx_hal.h"  // Include HAL library for STM32G4 series
#include "TESTBENCH.h"

#define RESOLUTION 4096             // Define the resolution for the data arrays
#define NO_OF_CYCLES 15             // Define the number of CORDIC cycles
#define PI 3.14159265358979323846   // Define the value of PI

CORDIC_HandleTypeDef hcordic;       // CORDIC handler declaration
UART_HandleTypeDef hlpuart1;        // UART handler declaration

const uint32_t CyclePrecision[] =   // Array to hold precision values for different CORDIC cycles
{
    CORDIC_PRECISION_1CYCLE,
    CORDIC_PRECISION_2CYCLES,
    CORDIC_PRECISION_3CYCLES,
    CORDIC_PRECISION_4CYCLES,
    CORDIC_PRECISION_5CYCLES,
    CORDIC_PRECISION_6CYCLES,
    CORDIC_PRECISION_7CYCLES,
    CORDIC_PRECISION_8CYCLES,
    CORDIC_PRECISION_9CYCLES,
    CORDIC_PRECISION_10CYCLES,
    CORDIC_PRECISION_11CYCLES,
    CORDIC_PRECISION_12CYCLES,
    CORDIC_PRECISION_13CYCLES,
    CORDIC_PRECISION_14CYCLES,
    CORDIC_PRECISION_15CYCLES
};

/* Define the possible states of the machine */
typedef enum {
    IDLE,                 /* Initialization state */
    START_CORDIC,         /* Sampling state */
    UART_TRANSFER,        /* UART transfer state */
} Machine_state;

/* Define a structure to hold machine state and related variables */
typedef struct {
    Machine_state state;              /* State variable */
    uint8_t Cycles;                   /* Counter variable */
    int32_t DataIn[RESOLUTION];       /* Buffer to store ADC values */
    int32_t DataOut[RESOLUTION];      /* Buffer to store ADC values */
    uint8_t ReceivedByte;             /* Buffer to store received byte */
    uint32_t LATENCY;                 /* Buffer to store latency values */
} Machine_state_t;

/* Create and initialize a static machine state object */
static Machine_state_t machineState = {IDLE, 0, {0}, {0}, 0, 0};

/* State machine function */
void TestBench() {

    SIGNAL_SCALING();  // Call signal scaling function
    /* Infinite loop to run the state machine */
    while (1) {
        /* State machine switch-case */
        switch (machineState.state) {
            case IDLE:
                if (HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_13)) {  // Check if GPIO pin is set
                    machineState.state = START_CORDIC;      // Transition to START_CORDIC state
                }
                break;

            case START_CORDIC:
                FLASH_FlushCaches();  // Flush the cache
                Cordic_Start(CyclePrecision[machineState.Cycles]);  // Start CORDIC with current cycle precision
                CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;  // Enable the trace and debug block
                DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;  // Enable the cycle counter
                DWT->CYCCNT = 0;  // Reset the cycle counter

                // Write and read to WDATA and RDATA
                for (int i = 0; i < RESOLUTION; i++) {
                    CORDIC->WDATA = machineState.DataIn[i];   // Write data to CORDIC
                    machineState.DataOut[i] = CORDIC->RDATA;  // Read data from CORDIC
                }

                // Get the end cycle count
                machineState.LATENCY = DWT->CYCCNT;  // Store the latency
                DWT->CTRL &= ~DWT_CTRL_CYCCNTENA_Msk;  // Disable the cycle counter

                machineState.state = UART_TRANSFER;  // Transition to UART_TRANSFER state
                break;

            case UART_TRANSFER:
                TRANSMIT_CORDIC_VALUE();   // Transmit CORDIC values over UART
                TRANSMIT_LATENCY_VALUE();  // Transmit latency value over UART
                HAL_UART_Receive(&hlpuart1, &machineState.ReceivedByte, 1, 100);
                if (machineState.ReceivedByte == 1) {
                    machineState.state = START_CORDIC;  // Transition back to START_CORDIC state
                    machineState.ReceivedByte = 0;
                    machineState.Cycles = machineState.Cycles + 1;  // Update cycle count
                }
                else if (machineState.Cycles == NO_OF_CYCLES) {
                    machineState.state = IDLE;  // Transition back to IDLE state
                }
                break;
        }
    }
}

/* Function to perform signal scaling */
void SIGNAL_SCALING() {
    double step = 360.0 / RESOLUTION;  // Calculate step size

    for (int i = 0; i < RESOLUTION; i++) {
        machineState.DataIn[i] = (int32_t)((((step * i * 3.141592653 / 180.0 - 3.141592653) / 3.141592653)) * 2147483647);  // Scale signal data
    }
}

/* Function to transmit latency value over UART */
void TRANSMIT_LATENCY_VALUE() {
    for (int k = 0; k < 4; k++) {
        uint8_t splittingdata = (machineState.LATENCY >> 8 * k) & 0xFF;  // Split latency value into 4 bytes
        HAL_UART_Transmit(&hlpuart1, &splittingdata, 1, 100);            // Transmit each byte
    }
}

/* Function to transmit CORDIC values over UART */
void TRANSMIT_CORDIC_VALUE() {
    for (int i = 0; i < RESOLUTION; i++) {
        /* Send the 32-bit value in 4 transfers */
        for (int k = 0; k < 4; k++) {
            uint8_t splittingdata = (machineState.DataOut[i] >> 8 * k) & 0xFF;  // Split data into 4 bytes
            HAL_UART_Transmit(&hlpuart1, &splittingdata, 1, 100);               // Transmit each byte
        }
    }
}

/* Function to configure and start CORDIC */
void Cordic_Start(uint32_t CYCLES_PRECISION) {
    CORDIC_ConfigTypeDef sConfig;
    sConfig.Function  = CORDIC_FUNCTION_SINE;  // Set function to sine
    sConfig.Precision = CYCLES_PRECISION;      // Set precision
    sConfig.Scale     = CORDIC_SCALE_0;        // Set scale
    sConfig.NbWrite   = CORDIC_NBWRITE_1;      // Set number of writes
    sConfig.NbRead    = CORDIC_NBREAD_1;       // Set number of reads
    sConfig.InSize    = CORDIC_INSIZE_32BITS;  // Set input size
    sConfig.OutSize   = CORDIC_OUTSIZE_32BITS; // Set output size
    HAL_CORDIC_Configure(&hcordic, &sConfig);  // Configure CORDIC
}
