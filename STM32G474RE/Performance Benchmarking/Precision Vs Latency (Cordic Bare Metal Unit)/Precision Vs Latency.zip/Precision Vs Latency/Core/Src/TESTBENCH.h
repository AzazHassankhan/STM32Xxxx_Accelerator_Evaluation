/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

/* Function prototype for starting the CORDIC with specified precision */
void Cordic_Start(uint32_t CYCLES_PRECISION);

/* Function prototype for scaling the signal */
void SIGNAL_SCALING();

/* Function prototype for transmitting the latency value */
void TRANSMIT_LATENCY_VALUE();

/* Function prototype for transmitting the CORDIC values */
void TRANSMIT_CORDIC_VALUE();

/* Function prototype to handle the state machine logic for the game */
void TestBench();

/* [] END OF FILE */
